# Sistema de Gerenciamento de Equipamentos

Projeto Django preparado para rodar em **GitHub Codespaces**.

## Rodando no Codespaces

Ao abrir o repositório em um novo Codespace, o arquivo `.devcontainer/devcontainer.json` instala as dependências e executa as migrations automaticamente.

O servidor é iniciado em `0.0.0.0:8000` e a porta 8000 é encaminhada pelo Codespaces.

## Rodando manualmente

```bash
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver 0.0.0.0:8000
```

## Funcionalidades

- Dashboard de equipamentos
- Cadastro
- Edição
- Exclusão
- Visualização dos detalhes
- Painel administrativo do Django

O banco padrão é SQLite, portanto não é necessário configurar MySQL ou outro banco para iniciar o projeto.
