from django.test import TestCase
from django.urls import reverse

from .models import Equipamento


class EquipamentoTests(TestCase):
    def setUp(self):
        self.equipamento = Equipamento.objects.create(
            nome="Notebook",
            numero_patrimonio=12345,
            tipo="Informática",
            em_uso=False,
        )

    def test_dashboard_abre(self):
        response = self.client.get(reverse("dashboard"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Notebook")

    def test_detalhe_abre(self):
        response = self.client.get(
            reverse("detalhe_equipamento", args=[self.equipamento.id])
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "12345")

    def test_cadastro(self):
        response = self.client.post(
            reverse("cadastrar_equipamento"),
            {
                "nome": "Monitor",
                "numero_patrimonio": 67890,
                "tipo": "Informática",
                "em_uso": "on",
            },
        )
        self.assertRedirects(response, reverse("dashboard"))
        self.assertTrue(Equipamento.objects.filter(nome="Monitor").exists())

    def test_edicao(self):
        response = self.client.post(
            reverse("editar_equipamento", args=[self.equipamento.id]),
            {
                "nome": "Notebook atualizado",
                "numero_patrimonio": 54321,
                "tipo": "Informática",
                "em_uso": "on",
            },
        )
        self.assertRedirects(response, reverse("dashboard"))
        self.equipamento.refresh_from_db()
        self.assertEqual(self.equipamento.nome, "Notebook atualizado")

    def test_exclusao_exige_post(self):
        get_response = self.client.get(
            reverse("deletar_equipamento", args=[self.equipamento.id])
        )
        self.assertRedirects(get_response, reverse("dashboard"))
        self.assertTrue(Equipamento.objects.filter(id=self.equipamento.id).exists())

        post_response = self.client.post(
            reverse("deletar_equipamento", args=[self.equipamento.id])
        )
        self.assertRedirects(post_response, reverse("dashboard"))
        self.assertFalse(Equipamento.objects.filter(id=self.equipamento.id).exists())
