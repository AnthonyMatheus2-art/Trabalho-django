# Projeto Django — Controle de Equipamentos

Aplicação Django para cadastrar, consultar, editar e excluir equipamentos.

## Rodando no GitHub Codespaces

1. Abra o repositório no GitHub.
2. Clique em **Code → Codespaces → Create codespace on main**.
3. O Codespace instala as dependências e executa as migrações automaticamente.
4. Quando a porta `8000` for encaminhada, abra a aplicação pelo endereço mostrado pelo Codespaces.

Se precisar executar manualmente:

```bash
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py runserver 0.0.0.0:8000
```

## Banco de dados

O projeto usa SQLite por padrão. O arquivo `db.sqlite3` é criado automaticamente quando as migrações são executadas.

## Variáveis de ambiente

O Codespace cria `.env` a partir de `.env.example`. O arquivo `.env` não é versionado pelo Git.
